import {NextResponse} from 'next/server';
import {createClient} from '@supabase/supabase-js';
export const runtime='nodejs';
export async function POST(request:Request){
 try{
  const body=await request.json();
  const {name='',email='',platform='Windows PC',genre='Both',reason='',consent=false}=body;
  if(!consent||typeof email!=='string'||email.length>254||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))return NextResponse.json({error:'Enter a valid email and agree to be contacted.'},{status:400});
  if(typeof name!=='string'||name.length>100||typeof reason!=='string'||reason.length>1000||!['Windows PC','Mac','Linux'].includes(platform)||!['Both','Management games','First-person simulators'].includes(genre))return NextResponse.json({error:'Please check the form fields.'},{status:400});
  const url=process.env.SUPABASE_URL,key=process.env.SUPABASE_SERVICE_ROLE_KEY;
  if(!url||!key)return NextResponse.json({error:'Applications are not configured yet. Please check back soon.'},{status:503});
  const supabase=createClient(url,key,{auth:{persistSession:false}});
  const {error}=await supabase.from('early_access_applications').insert({name:name.trim()||null,email:email.trim().toLowerCase(),platform,genre,reason:reason.trim()||null,consent:true,status:'pending'});
  if(error){if(error.code==='23505')return NextResponse.json({error:'This email has already requested access.'},{status:409});return NextResponse.json({error:'Unable to save your request right now.'},{status:500})}
  return NextResponse.json({ok:true});
 }catch{return NextResponse.json({error:'Invalid request.'},{status:400})}
}
