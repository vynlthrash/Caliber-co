"use client";
import Link from 'next/link';
import {usePathname} from 'next/navigation';
import {useState} from 'react';
import {Menu,X,ArrowUpRight} from 'lucide-react';
const links=[['/','OVERVIEW'],['/features','FEATURES'],['/roadmap','ROADMAP'],['/development','DEVLOG']];
export default function SiteHeader(){const path=usePathname();const [open,setOpen]=useState(false);return <header className="topbar"><div className="shell nav"><Link href="/" className="wordmark" onClick={()=>setOpen(false)}>CALIBER <span>&amp;</span> CO.<small>FIREARMS · OUTDOORS · SUPPLY</small></Link><button aria-label="Toggle navigation" className="mobile-toggle" onClick={()=>setOpen(!open)}>{open?<X/>:<Menu/>}</button><nav className={'links '+(open?'show':'')}>{links.map(([href,label])=><Link key={href} href={href} className={path===href?'selected':''} onClick={()=>setOpen(false)}>{label}</Link>)}<Link href="/early-access" className="nav-cta" onClick={()=>setOpen(false)}>EARLY ACCESS <ArrowUpRight size={15}/></Link></nav></div></header>}
