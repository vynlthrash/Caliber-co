import './globals.css';import SiteHeader from './components/SiteHeader';import Footer from './components/Footer';
export const metadata={title:'Caliber & Co. | Firearms Retail Management',description:'Build and manage your own firearms retail business. Explore detailed planned systems, development progress, and request playtest access.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body><SiteHeader/>{children}<Footer/></body></html>}
