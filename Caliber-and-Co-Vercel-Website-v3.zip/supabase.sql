-- Run in Supabase SQL Editor. Public clients cannot read applicant information.
create table if not exists public.early_access_applications (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  name text,
  email text not null unique,
  platform text not null,
  genre text not null,
  reason text,
  consent boolean not null default false,
  status text not null default 'pending' check (status in ('pending','shortlisted','accepted','rejected'))
);
alter table public.early_access_applications enable row level security;
-- No public RLS policies. Server-side service role inserts; only project admins review.
create index if not exists early_access_status_created on public.early_access_applications(status,created_at desc);
