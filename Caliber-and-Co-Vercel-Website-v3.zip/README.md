# Caliber & Co. — Vercel website (v2)

A multi-page Next.js website for the game Caliber & Co. No generated gameplay screenshots.

## Pages
- `/` — concise home/overview
- `/features` — 22 searchable, filterable feature specifications with dependencies and status
- `/roadmap` — six-phase development roadmap
- `/development` — devlog placeholder for real updates
- `/early-access` — application form
- `/admin` — instructions for securely reviewing applications in Supabase

## Run locally
```bash
npm install
npm run dev
```

## Deploy to Vercel
Push the project to GitHub, import the repository in Vercel, and deploy with the default Next.js settings. For application collection, create a Supabase project, run `supabase.sql`, and set `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` in Vercel Environment Variables. Redeploy after setting them. **Without Supabase, the form clearly reports that applications are not configured; it does not falsely claim to save them.**

## Edit the site
- Feature descriptions, stages, dependencies and roadmap: `lib/features.ts`
- Logo: `public/logo.svg`
- Colors and layout: `app/globals.css`
- Page content: `app/*/page.tsx`
- Application handling: `app/api/apply/route.ts`

## Status accuracy
Construction and top-down interface are described as already largely implemented based on developer input, not independently verified. First-person mode is described as in development based on developer intent; adjust any stage labels in `lib/features.ts` to match the actual build.

## Security
The Supabase service-role key must stay server-side. The `/admin` route does not expose private applicant data or a fake admin login. Before accepting public submissions, add anti-spam/rate limiting and a contact/privacy policy; consider double opt-in if sending marketing updates.


## V3 feature registry update (October 22, 2026)
- `lib/features.ts` is the source of truth for 47 tracked systems, dependencies, stage labels, and 8 roadmap phases.
- Features reported by the developer as implemented are labeled **Implemented / in refinement**; no automated code verification is implied.
- The parody manufacturer catalog is explicitly incomplete. Weather-driven shipping disruption is planned rather than marked complete.
- `app/development/page.tsx` contains the developer-reported status update.
- No fake gameplay screenshots are included.
- IMPORTANT: In Vercel, set the project root directory to `caliber-co-site` if the repository retains the outer folder. Otherwise move the contents of that folder to the repository root.
